#ifndef _SelectGameScene_H_
#define _SelectGameScene_H_

#include "cocos2d.h"
#include "editor-support/cocostudio/CCSGUIReader.h"
#include "ui/CocosGUI.h"
USING_NS_CC;
using namespace ui;
using namespace cocostudio;

class SelectGameScene : public Layer
{
public:
	static Scene* createScene();
	virtual bool init();
	CREATE_FUNC(SelectGameScene);
public:
	void loadUI();
	void loadSprite();
public:
	void BeginGame_1(Ref*, TouchEventType type);//��ת���ǳ�����
	void BeginGame_2(Ref*, TouchEventType type);//��ʾ�����ڴ��ı�ǩ
	void Return(Ref*, TouchEventType type);//��ת�����ó���
private:
	Sprite* m_sprite;
};

#endif
