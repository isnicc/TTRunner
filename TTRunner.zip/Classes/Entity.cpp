#include "Entity.h"

Entity::Entity()
{
	m_sprite = NULL;
}

Entity::~Entity(){}

Sprite* Entity::getSprite()
{
	return m_sprite;
}

void Entity::bindSprite(Sprite* sprite)
{
	this->m_sprite = sprite;
	this->addChild(m_sprite);

	Size size = m_sprite->getContentSize();
	this->setPosition(Point( - size.width / 2,  - size.height / 2));
	this->setContentSize(size);
	
}