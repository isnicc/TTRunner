#ifndef _SettingScene_H_
#define _SettingScene_H_

#include "cocos2d.h"
#include "editor-support/cocostudio/CCSGUIReader.h"
#include "ui/CocosGUI.h"
USING_NS_CC;
using namespace ui;
using namespace cocostudio;

class SettingScene : public Layer
{
public:
	static Scene* createScene();
	virtual bool init();
	CREATE_FUNC(SettingScene);
public:
	void loadUI();
	void loadSprite();
	int getVolume();
	void isPlaying();
public:
	void Return(Ref*, TouchEventType type);//����֮ǰ����
	void More(Ref*, TouchEventType type);//��ת�����ೡ��
	void BanVolume(Ref*, TouchEventType type);//��ֹ��������
private:
	Sprite* m_sprite;
	int m_volume;
	bool m_isPlaying;
};

#endif