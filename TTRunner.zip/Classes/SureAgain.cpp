#include "SureAgain.h"
#include "LogoutScene.h"
#include "InitScene.h"

Scene* SureAgain::createScene(RenderTexture* renderTexture)
{
	auto scene = Scene::create();
	auto layer = SureAgain::create();
	scene->addChild(layer, 1);

	Size visibleSize = Director::getInstance()->getVisibleSize();

	//�������д������û�õ�������Ҳ���ǽ�ͼ������һ�����飬����������Ϊ����
	Sprite* background = Sprite::createWithTexture(renderTexture->getSprite()->getTexture());
	background->setPosition(Point(visibleSize.width / 2, visibleSize.height / 2));
	background->setFlippedY(true);   //������Ҫ��ֱ��ת����Ϊ����OpenGL����
	background->setColor(ccc3(128,128,128));   //����ͼƬΪ��ɫ
	scene->addChild(background, 0);

	return scene;
}

bool SureAgain::init()
{
	if (!Layer::init())
	{
		return false;
	}

	loadUI();

	return true;
}


void SureAgain::loadUI()
{
	auto UI = GUIReader::getInstance()->widgetFromJsonFile("LogoutScene_1_1.ExportJson");
	UI->setPosition(Point(0, 0));
	this->addChild(UI, 1);

	Button* btn_1 = (Button*)Helper::seekWidgetByName(UI, "yes");
	Button* btn_2 = (Button*)Helper::seekWidgetByName(UI, "no");

	btn_1->addTouchEventListener(this, toucheventselector(SureAgain::Logout));
	btn_2->addTouchEventListener(this, toucheventselector(SureAgain::Return));
}

void SureAgain::Logout(Ref*, TouchEventType type)
{
	switch(type)
	{
	case TouchEventType::TOUCH_EVENT_ENDED:
		Director::getInstance()->replaceScene(InitScene::createScene());
		break;
	}
}

void SureAgain::Return(Ref*, TouchEventType type)
{
	switch (type)
	{
	case TouchEventType::TOUCH_EVENT_ENDED:
		Director::getInstance()->popScene();
		break;
	}

}