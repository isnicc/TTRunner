#ifndef _InitScene_H_
#define _InitScene_H_

#include "cocos2d.h"
#include "editor-support/cocostudio/CCSGUIReader.h"
#include "ui/CocosGUI.h"

using namespace cocos2d::ui;
using namespace cocostudio;
using namespace cocos2d;

class InitScene : public Layer
{
public:
	static Scene* createScene();
	virtual bool init();
	CREATE_FUNC(InitScene);
public:
	void loadUI();
	void loadSprite();
	void menuCloseCallBack(Ref* pSender, TouchEventType type);//��¼��������
};

#endif


