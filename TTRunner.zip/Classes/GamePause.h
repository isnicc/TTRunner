#ifndef _GamePause_H_
#define _GamePause_H_


#include "editor-support/cocostudio/CCSGUIReader.h"
#include "ui/CocosGUI.h"
#include "cocos2d.h"
USING_NS_CC;
using namespace cocos2d::ui;
using namespace cocostudio;

class GamePause : public Layer
{
public:
	static Scene* createScene(RenderTexture* renderTexture);
	virtual bool init();;
	CREATE_FUNC(GamePause);
public:
	void loadUI();
	void backToGame(Ref*, TouchEventType type);
	void restartGame(Ref*, TouchEventType type);
	void backToRankingScene(Ref*, TouchEventType type);
};


#endif
