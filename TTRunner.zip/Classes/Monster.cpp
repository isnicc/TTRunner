#include "Monster.h"

Monster::Monster()
{
	m_isAlive = false;
}

Monster::~Monster(){}

bool Monster::init()
{
	m_x = 800;
	this->scheduleUpdate();
	return true;
}

void Monster::show()
{
	if(getSprite() != NULL)
	{
		setVisible(true);
		m_isAlive = true;
	}
}

void Monster::hide()
{
	if(getSprite() != NULL)
	{
		setVisible(false);
		reset();
		m_isAlive = false;
	}
}

void Monster::reset()
{
	if (getSprite() != NULL)
	{
		setPosition(m_x + CCRANDOM_0_1() * 1000, 300 + CCRANDOM_0_1() * 100);
	}
}

bool Monster::isAlive()
{
	return m_isAlive;
}

bool Monster::isCollideWithPlayer(Player* player)
{
	Rect entityRect = player->getBoundingBox();

	Point monsterPos = getPosition();

	return entityRect.containsPoint(monsterPos);
}

void Monster::update(float dt)
{
	m_x += 5;
}