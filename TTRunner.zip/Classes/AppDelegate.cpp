#include "AppDelegate.h"
#include "HelloWorldScene.h"
#include "TollgateScene.h"
#include "InitScene.h"
#include "iconv.h"

#include "SimpleAudioEngine.h"

#pragma comment(lib,"libiconv.lib")   
USING_NS_CC;

AppDelegate::AppDelegate() {

}

AppDelegate::~AppDelegate() 
{
}

bool AppDelegate::applicationDidFinishLaunching() {
    // initialize director
    auto director = Director::getInstance();
    auto glview = director->getOpenGLView();
    if(!glview) {

		std::string str = "������ܴ���ҵ��";
		GBKToUTF8(str);
        glview = GLView::create(Value(str).asString());
		glview->setFrameSize(800, 500);
        director->setOpenGLView(glview);
    }

    // turn on display FPS
    director->setDisplayStats(false);

    // set FPS. the default value is 1.0/60 if you don't call this
    director->setAnimationInterval(1.0 / 60);

    // create a scene. it's an autorelease object
    auto scene = InitScene::createScene();


	CocosDenshion::SimpleAudioEngine::getInstance()->preloadBackgroundMusic("runBgm.mp3");
	CocosDenshion::SimpleAudioEngine::getInstance()->preloadBackgroundMusic("TTRunBgm.mp3");
	CocosDenshion::SimpleAudioEngine::getInstance()->preloadEffect("addScore.wav");

    // run
    director->runWithScene(scene);

	

    return true;
}

// This function will be called when the app is inactive. When comes a phone call,it's be invoked too
void AppDelegate::applicationDidEnterBackground() {
    Director::getInstance()->stopAnimation();

    // if you use SimpleAudioEngine, it must be pause
    CocosDenshion::SimpleAudioEngine::getInstance()->pauseBackgroundMusic();
}

// this function will be called when the app is active again
void AppDelegate::applicationWillEnterForeground() {
    Director::getInstance()->startAnimation();

    // if you use SimpleAudioEngine, it must resume here
    CocosDenshion::SimpleAudioEngine::getInstance()->resumeBackgroundMusic();
}

  

int AppDelegate::GBKToUTF8(std::string &gbkStr)      
{      
	iconv_t iconvH;      

	iconvH              = iconv_open("utf-8","gb2312");      
	if(iconvH == 0){      
		return -1;      
	}      
	const char* strChar = gbkStr.c_str();      
	const char** pin    = &strChar;      

	size_t strLength    = gbkStr.length();      
	char* outbuf        = (char*)malloc(strLength*4);      
	char* pBuff         = outbuf;      
	memset(outbuf,0,strLength*4);      
	size_t outLength    = strLength*4;      
	if(-1 == iconv(iconvH,pin,&strLength,&outbuf,&outLength)){      
		iconv_close(iconvH);      
		return -1;      
	}      
	gbkStr              =   pBuff;      
	iconv_close(iconvH);      
	return 0;      
}   