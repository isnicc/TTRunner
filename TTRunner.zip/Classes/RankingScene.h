#ifndef _RankingScene_H_
#define _RankingScene_H_

#include "cocos2d.h"
#include "editor-support/cocostudio/CCSGUIReader.h"
#include "ui/CocosGUI.h"

#include "json\writer.h"
#include "json\reader.h"
#include "json\value.h"

USING_NS_CC;
using namespace cocos2d::ui;
using namespace cocostudio;

class RankingScene : public Layer
{
public:
	static Scene* createScene();
	virtual bool init();
	CREATE_FUNC(RankingScene);
public:
	void loadUI();
	void readData();
	void show();
	void Return(Ref*, TouchEventType type);
private:
	Text* m_NO1Lab;
	Text* m_NO2Lab;
	Text* m_NO3Lab;
private:
	int m_NO1;
	int m_NO2;
	int m_NO3;
};


#endif // !_RankingScene_H_
