#include "LogoutScene.h"
#include "SureAgain.h"
#include "SettingScene.h"
#include "MainScene.h"

Scene* LogoutScene::createScene()
{
	auto scene = Scene::create();
	auto layer = LogoutScene::create();
	scene->addChild(layer);
	return scene;
}

bool LogoutScene::init()
{
	if (!Layer::init())
	{
		return false;
	}

	Size size = Director::getInstance()->getVisibleSize();

	auto sprite = Sprite::create("background.png");
	sprite->setPosition(Point(size.width / 2, size.height / 2));
	this->addChild(sprite, 0);

	loadUI();

	return true;
}


void LogoutScene::loadUI()
{
	auto UI = GUIReader::getInstance()->widgetFromJsonFile("LogoutScene_1.ExportJson");
	UI->setPosition(Point(0, 0));
	this->addChild(UI, 1);

	Button* btn_1 = (Button*)Helper::seekWidgetByName(UI, "logout");
	Button* btn_2 = (Button*)Helper::seekWidgetByName(UI, "setting");
	Button* btn_3 = (Button*)Helper::seekWidgetByName(UI, "return");

	btn_1->addTouchEventListener(this, toucheventselector(LogoutScene::Logout));
	btn_2->addTouchEventListener(this, toucheventselector(LogoutScene::Set));
	btn_3->addTouchEventListener(this, toucheventselector(LogoutScene::Return));
}

void LogoutScene::Logout(Ref*, TouchEventType type)
{
	switch (type)
	{
	case TouchEventType::TOUCH_EVENT_ENDED:

		Size visibleSize = Director::getInstance()->getVisibleSize();
		RenderTexture* texture = RenderTexture::create(visibleSize.width, visibleSize.height);

		//������ǰ��������ӽڵ㣬������texture���൱�ڽ�ͼ
		texture->begin();
		this->getParent()->visit();
		texture->end();


		//Ҫʵ�ֽ�ͼ���ܣ����ﲻ����replaceScene
		Director::getInstance()->pushScene(SureAgain::createScene(texture));
		break;
	}
}

void LogoutScene::Set(Ref*, TouchEventType type)
{
	switch (type)
	{
	case TouchEventType::TOUCH_EVENT_ENDED:
		Director::getInstance()->pushScene(SettingScene::createScene());
		break;
	}
}

void LogoutScene::Return(Ref*, TouchEventType type)
{
	switch (type)
	{
	case TouchEventType::TOUCH_EVENT_ENDED:
		Director::getInstance()->replaceScene(MainScene::createScene());
		break;
	}
}