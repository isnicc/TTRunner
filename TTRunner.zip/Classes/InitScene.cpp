#include "InitScene.h"
#include "MainScene.h"
#include "SimpleAudioEngine.h"

Scene* InitScene::createScene()
{
	auto scene = Scene::create();
	auto layer = InitScene::create();
	scene->addChild(layer);
	return scene;
}

bool InitScene::init()
{
	if (!Layer::init())
	{
		return false;
	}

	CocosDenshion::SimpleAudioEngine::getInstance()->playBackgroundMusic("TTRunBgm.mp3", true);

	Size size = Director::getInstance()->getVisibleSize();
	auto sprite = Sprite::create("TTRunGame.png");
	sprite->setPosition(Point(size.width / 2, size.height / 2));
	this->addChild(sprite, 0);

	loadUI();
	loadSprite();

	return true;
}

void InitScene::loadUI()
{
	auto UI = cocostudio::GUIReader::getInstance()->
			widgetFromJsonFile("TTRunUI_1_1.ExportJson");
	UI->setPosition(Point(0, 0));
	this->addChild(UI, 3);

	Button* btn1 = (Button*)Helper::seekWidgetByName(UI, "weixinBtn");
	Button* btn2 = (Button*)Helper::seekWidgetByName(UI, "qqBtn");
	Button* btn3 = (Button*)Helper::seekWidgetByName(UI, "vistorBtn");

	btn1->addTouchEventListener(this, toucheventselector(InitScene::menuCloseCallBack));
	btn2->addTouchEventListener(this, toucheventselector(InitScene::menuCloseCallBack));
	btn3->addTouchEventListener(this, toucheventselector(InitScene::menuCloseCallBack));

}

void InitScene::loadSprite()  //������������
{
	Size size = Director::getInstance()->getVisibleSize();

	Sprite* sprite1 = Sprite::create("shuili1.png");
	sprite1->setPosition(Point(size.width / 2 - 100, size.height / 2 - 50));
	this->addChild(sprite1, 1);

	Sprite* sprite2 = Sprite::create("jinqiang1.png");
	sprite2->setPosition(Point(size.width / 2 + 50, size.height / 2));
	this->addChild(sprite2, 2);

	Sprite* sprite3 = Sprite::create("baixue1.png");
	sprite3->setPosition(Point(size.width / 2 + 200,size.height / 2 - 50));
	this->addChild(sprite3, 1);

	SpriteFrameCache* frameCache = SpriteFrameCache::getInstance();
	frameCache->addSpriteFramesWithFile("InitScene.plist", "InitScene.png");

	SpriteFrame* frame = NULL;
	Vector<SpriteFrame*> frameList1;
	Vector<SpriteFrame*> frameList2;
	Vector<SpriteFrame*> frameList3;

	for(int i = 1; i <= 3; i++)
	{
		frame = frameCache->getSpriteFrameByName(StringUtils::format("shuili%d.png", i));
		frameList1.pushBack(frame);
		frame = frameCache->getSpriteFrameByName(StringUtils::format("jinqiang%d.png", i));
		frameList2.pushBack(frame);
		frame = frameCache->getSpriteFrameByName(StringUtils::format("baixue%d.png", i));
		frameList3.pushBack(frame);
	}
	
	Animation* animation1 = Animation::createWithSpriteFrames(frameList1);
	animation1->setLoops(-1);
	animation1->setDelayPerUnit(0.5f);
	Animate* action1 = Animate::create(animation1);
	sprite1->runAction(action1);

	Animation* animation2 = Animation::createWithSpriteFrames(frameList2);
	animation2->setLoops(-1);
	animation2->setDelayPerUnit(0.5f);
	Animate* action2 = Animate::create(animation2);
	sprite2->runAction(action2);

	Animation* animation3 = Animation::createWithSpriteFrames(frameList3);
	animation3->setLoops(-1);
	animation3->setDelayPerUnit(0.5f);
	Animate* action3 = Animate::create(animation3);
	sprite3->runAction(action3);
}


void InitScene::menuCloseCallBack(Ref* pSender, TouchEventType type) //ע�ⰴť�����ص������Ĳ���
{
	switch(type)
	{
	case TouchEventType::TOUCH_EVENT_ENDED:
		/*��������δ���Ҳ����ʵ�ֳ����л��������������HelloWorld��menuCloseCallBack��
		��ֻ�б�ע�͵���һ�δ������ʵ�ֳ����л���
		auto scene = Scene::create(); 
		scene->addChild(TollgateScene::create());
		Director::getInstance()->replaceScene(scene);*/

		Director::getInstance()->replaceScene(MainScene::createScene());
		break;
	}
	
}

