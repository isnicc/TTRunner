#include "TollgateScene.h"
#include "SimpleAudioEngine.h"
#include "GamePause.h"
#include "GameEndScene.h"

#include "json\writer.h"
#include "json\reader.h"
#include "json\value.h"

USING_NS_CC;

Scene* TollgateScene::createScene()
{
	auto scene = Scene::create();
	auto layer = TollgateScene::create();
	scene->addChild(layer);
	return scene;
}

bool TollgateScene::init()//�����ڵ���㣬�����ڵ�����
{
	if(!Layer::init())
	{
		return false;
	}

	auto func = [&](){
		CocosDenshion::SimpleAudioEngine::getInstance()->playBackgroundMusic("runBgm.mp3", true);

		m_countDownSprite->removeFromParent(); 

		m_player->runAction(m_player->run());
		m_player->scheduleUpdate();

		m_monsterManager->scheduleUpdate();
	};

	Size winSize = Director::getInstance()->getWinSize();
	m_countDownSprite = Sprite::create("CountDown1.png");
	m_countDownSprite->setPosition(Point(winSize.width / 2, winSize.height / 2));
	this->addChild(m_countDownSprite, 10);
	m_countDownSprite->runAction(this->loadSprite());
	
	this->scheduleOnce(schedule_selector(TollgateScene::CountDownMusic), 1.0f);
	

	this->initBG();
	this->loadUI();

	m_player = Player::create("shuanqiang1.png");
	m_player->setPosition(Point(20, 195));
	m_player->setData();

	TMXTiledMap* map = TMXTiledMap::create("map.tmx");
	this->setMap(map);
	m_player->setTiledMap(map);
	this->addPlayer();

	this->scheduleUpdate();
	this->CountDown(3.0f, func);

	return true;
}

void TollgateScene::CountDownMusic(float dt)
{
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("readygo.wav");
}

void TollgateScene::update(float delta)       //�õ�ͼ����ѭ������
{
	if (m_isCounting == true)
	{
		m_fTime += delta;
		if (m_fTime < m_fCBTime)
		{
			return;
		}
		else
		{
			m_func();
			m_isCounting = false;
			return;
		}
	}

	this->show();

	int posX1 = m_bgSprite1->getPositionX();
	int posX2 = m_bgSprite2->getPositionX();
	int posX3 = m_bgSprite3->getPositionX();
	int posX4 = m_bgSprite4->getPositionX();
	int posX5 = m_bgSprite5->getPositionX();

	int iSpeed1 = 1;    //��ͼԽԶ���ٶ�Խ��
	int iSpeed2 = 2;
	int iSpeed3 = 3;

	//�Ա���1�������޹�������
	posX1 -= iSpeed1;
	posX2 -= iSpeed1;
	Size mapSize1 = m_bgSprite1->getContentSize(); //��õ�ͼ��С�������жϵ�ͼλ��
	//������Ҫ�޸Ļ�õĵ�ͼ�ߴ磬�����ں��治��ƴ�ӵ�ʱ�򲻶���ȥ��϶
	mapSize1.width -= 6;

	if(posX1 <= -mapSize1.width / 2)
	{
		posX1 = mapSize1.width + mapSize1.width / 2;
	}
	if(posX2 <= -mapSize1.width / 2)
	{
		posX2 = mapSize1.width + mapSize1.width / 2;
	}
	m_bgSprite1->setPositionX(posX1);
	m_bgSprite2->setPositionX(posX2);



	posX3 -= iSpeed2;
	if(posX3 <= - 2 * mapSize1.width)
	{
		posX3 = mapSize1.width + mapSize1.width / 2;
	}
	m_bgSprite3->setPositionX(posX3);

	//�Ա���3�������޹�������
	posX4 -= iSpeed3;
	posX5 -= iSpeed3;
	Size mapSize2 = m_bgSprite4->getContentSize(); //��õ�ͼ��С�������жϵ�ͼλ��
	//ԭ��ͬ��
	mapSize2.width -= 4;

	if(posX4 <= -mapSize2.width / 2)
	{
		posX4 = mapSize2.width + mapSize2.width / 2;
	}
	if(posX5 <= -mapSize2.width / 2)
	{
		posX5 = mapSize2.width + mapSize2.width / 2;
	}
	m_bgSprite4->setPositionX(posX4);
	m_bgSprite5->setPositionX(posX5);


	if (m_player->getHp() <= 0)
	{
		m_name = "defeat.png";
		this->writeData();
		this->gameEnd();
	}
	if (m_player->isVictory())
	{
		m_name = "victory.png";
		this->writeData();
		this->gameEnd();
	}
}

void TollgateScene::initBG()//����1�ڵ�һ�㣬����2�ڵڶ��㣬����3�ڵ�����
{
	Size visibleSize = Director::getInstance()->getVisibleSize();

	m_bgSprite1 = Sprite::create("Background1.png");
	m_bgSprite1->setPosition(Point(visibleSize.width / 2, visibleSize.height / 2));
	this->addChild(m_bgSprite1, 0);

	m_bgSprite2 = Sprite::create("Background1.png");
	//��ΪͼƬ��������������ƴ��֮���з�϶�����Ժ�����-2��ȥ��϶
	m_bgSprite2->setPosition(Point(visibleSize.width + visibleSize.width / 2 - 2, visibleSize.height / 2));
	this->addChild(m_bgSprite2, 1);

	m_bgSprite3 = Sprite::create("Background2.png");
	m_bgSprite3->setPosition(Point(visibleSize.width / 2, visibleSize.height / 2));
	this->addChild(m_bgSprite3, 2);

	m_bgSprite4 = Sprite::create("Background3.png");
	m_bgSprite4->setPosition(Point(visibleSize.width / 2, visibleSize.height / 2));
	this->addChild(m_bgSprite4, 3);

	m_bgSprite5 = Sprite::create("Background3.png");
	//��ΪͼƬ��������������ƴ��֮���з�϶�����Ժ�����-2��ȥ��϶
	//ע�⣬�����ȥ̫��Ļ�����ƴ��ʱ���к�������
	m_bgSprite5->setPosition(Point(visibleSize.width + visibleSize.width / 2 - 2, visibleSize.height / 2));
	this->addChild(m_bgSprite5, 3);
}

void TollgateScene::loadUI()     //������Ϸ�������Ծ���»�����ͣ��ť��UI�ڵ��߲�
{
	Size visibleSize = Director::getInstance()->getVisibleSize();

	auto UI = cocostudio::GUIReader::getInstance()
		->widgetFromJsonFile("TTRunUI_1.ExportJson");
	UI->setPosition(Point(0,0));
	this->addChild(UI, 7);

	auto jumpBtn = (Button*)Helper::seekWidgetByName(UI, "jumpBtn");
	auto slipBtn = (Button*)Helper::seekWidgetByName(UI, "slipBtn");
	auto pauseBtn = (Button*)Helper::seekWidgetByName(UI, "pauseBtn");
	m_scoreLab = (Text*)Helper::seekWidgetByName(UI, "scoreLab");
	m_distanceLab = (Text*)Helper::seekWidgetByName(UI, "distanceLab");
	m_hpBar = (LoadingBar*)Helper::seekWidgetByName(UI, "loadingBar");


	jumpBtn->addTouchEventListener(this, toucheventselector(TollgateScene::jumpEvent));
	slipBtn->addTouchEventListener(this, toucheventselector(TollgateScene::slipEvent));
	pauseBtn->addTouchEventListener(this, toucheventselector(TollgateScene::pause));
}

Action* TollgateScene::loadSprite()
{
	SpriteFrameCache* frameCache = SpriteFrameCache::getInstance();
	frameCache->addSpriteFramesWithFile("CountDown.plist", "CountDown.png");

	SpriteFrame* frame = NULL;
	Vector<SpriteFrame*> frameList;

	for (int i = 1; i <= 4; i++)
	{
		frame = frameCache->getSpriteFrameByName(StringUtils::format("CountDown%d.png", i));
		frameList.pushBack(frame);
	}

	Animation* animate = Animation::createWithSpriteFrames(frameList);
	animate->setLoops(1);
	animate->setDelayPerUnit(0.8f);

	Animate* action = Animate::create(animate);
	return action;
}

void TollgateScene::show()
{
	m_scoreLab->setText(Value(m_player->getScore()).asString());
	m_distanceLab->setText(Value(m_player->getDistance()).asString());
	m_hpBar->setPercent(m_player->getHpPercent());
}

void TollgateScene::writeData()
{
	this->rank();

	Json::Value root;
	Json::FastWriter writer;

	root["DistanceKey"] = m_player->getDistance();
	root["ScoreKey"] = m_player->getScore();
	root["HpKey"] = m_player->getHp();
	root["NO1Score"] = m_No1;
	root["NO2Score"] = m_No2;
	root["NO3Score"] = m_No3;
	root["SpriteName"] = m_name;

	std::string json_file = writer.write(root);

	FILE* file = fopen("GameData.json", "w");
	fprintf(file, json_file.c_str());
	fclose(file);
}

void TollgateScene::jumpEvent(Ref*, TouchEventType type)
{
	switch (type)
	{
	case TouchEventType::TOUCH_EVENT_ENDED:
		m_player->jump();
		break;
	}
}

void TollgateScene::slipEvent(Ref*, TouchEventType type)
{
	switch (type)
	{
	case TouchEventType::TOUCH_EVENT_BEGAN:
		if(!m_player->isJumping())
		{
			m_player->setSlippingState(true);
			Point pos = m_player->getPosition();
			pos.y -= 15;
			m_player->stopAllActions();
			m_player->runAction(m_player->slipAction());
			m_player->setPosition(pos);
			break;
		}
	case TouchEventType::TOUCH_EVENT_ENDED:
		if (!m_player->isJumping())
		{
			m_player->setSlippingState(false);
			Point pos = m_player->getPosition();
			pos.y += 15;
			m_player->setPosition(pos);
			m_player->runAction(m_player->run());
			break;
		}
	}
}

void TollgateScene::setMap(TMXTiledMap* map)
{
	m_map = map;
}

void TollgateScene::addPlayer()    ///�ѽ�ɫ���ӵ���ͼ�ϣ����ý�ɫʵ���ܵĶ���
{
	MonsterManager* monsterManager = MonsterManager::create();
	m_monsterManager = monsterManager;
	m_map->addChild(monsterManager, 10);
	monsterManager->bindPlayer(m_player);
	m_map->addChild(m_player, 5);
	this->addChild(m_map, 4);
}

void TollgateScene::pause(Ref*, TouchEventType type)
{
	switch (type)
	{
	case TouchEventType::TOUCH_EVENT_ENDED:
		Size visibleSize = Director::getInstance()->getVisibleSize();
		RenderTexture* texture = RenderTexture::create(visibleSize.width, visibleSize.height);

		//������ǰ��������ӽڵ㣬������texture���൱�ڽ�ͼ
		texture->begin();
		this->getParent()->visit();
		texture->end();

		CocosDenshion::SimpleAudioEngine::getInstance()->pauseBackgroundMusic();
		Director::getInstance()->pushScene(GamePause::createScene(texture));
		break;
	}
}

void TollgateScene::gameEnd()
{
	Size visibleSize = Director::getInstance()->getVisibleSize();
	RenderTexture* texture = RenderTexture::create(visibleSize.width, visibleSize.height);

	texture->begin();
	this->getParent()->visit();
	texture->end();

	CocosDenshion::SimpleAudioEngine::getInstance()->stopBackgroundMusic();

	Director::getInstance()->pushScene
			(GameEndScene::createScene(texture));
}

void TollgateScene::CountDown(float fCBtime, std::function<void()>func)
{
	m_isCounting = true;
	m_fTime = 0;
	m_fCBTime = fCBtime;
	m_func = func;
}

void TollgateScene::rank()
{
	m_currentScore = m_player->getScore();

	Json::Reader reader;
	Json::Value root;

	std::string data = FileUtils::getInstance()->getStringFromFile("GameData.json");

	if (reader.parse(data, root, false) == true)
	{
		m_No1 = root["NO1Score"].asInt();
		m_No2 = root["NO2Score"].asInt();
		m_No3 = root["NO3Score"].asInt();
	}

	if (m_currentScore <= m_No3)
	{
		return;
	}
	else 
	{
		if (m_currentScore <= m_No2)
		{
			m_No3 = m_currentScore;
		}
		else
		{
			if (m_currentScore <= m_No1)
			{
				m_No3 = m_No2;
				m_No2 = m_currentScore;
			}
			else
			{
				m_No3 = m_No2;
				m_No2 = m_No1;
				m_No1 = m_currentScore;
			}
		}
	}
}