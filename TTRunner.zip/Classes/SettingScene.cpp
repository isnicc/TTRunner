#include "SettingScene.h"
#include "SimpleAudioEngine.h"

Scene* SettingScene::createScene()
{
	auto scene = Scene::create();
	auto layer = SettingScene::create();
	scene->addChild(layer);
	return scene;
}

bool SettingScene::init()
{
	if (!Layer::init())
	{
		return false;
	}


	loadSprite();

	loadUI();

	return true;
}

void SettingScene::loadUI()
{
	auto UI = GUIReader::getInstance()->widgetFromJsonFile("SettingScene_1.ExportJson");
	UI->setPosition(Point(0, 0));
	this->addChild(UI, 1);

	Button* btn_1 = (Button*)Helper::seekWidgetByName(UI, "return");
	Button* btn_2 = (Button*)Helper::seekWidgetByName(UI, "volumeBtn");
	Button* btn_3 = (Button*)Helper::seekWidgetByName(UI, "more");
	LoadingBar* bar = (LoadingBar*)Helper::seekWidgetByName(UI, "volumeBar");

	btn_1->addTouchEventListener(this, toucheventselector(SettingScene::Return));
	btn_2->addTouchEventListener(this, toucheventselector(SettingScene::BanVolume));
	btn_3->addTouchEventListener(this, toucheventselector(SettingScene::More));
}

void SettingScene::loadSprite()
{
	Size size = Director::getInstance()->getVisibleSize();
	m_isPlaying = UserDefault::getInstance()->getBoolForKey("PlayingStateKey");

	auto sprite = Sprite::create("background.png");
	sprite->setPosition(Point(size.width / 2, size.height / 2));
	sprite->setColor(ccc3(128,128,128));
	this->addChild(sprite, 0);

	m_sprite = Sprite::create("ban.png");
	m_sprite->setScale(1.5f);
	m_sprite->setPosition(Point(282, 332));
	this->addChild(m_sprite, 2);
	if (!m_isPlaying)
	{
		m_sprite->setVisible(true);
	}
	if (m_isPlaying)
	{
		m_sprite->setVisible(false);
	}
}

void SettingScene::Return(Ref*, TouchEventType type)
{
	switch (type)
	{
	case TouchEventType::TOUCH_EVENT_ENDED:
		Director::getInstance()->popScene();
		break;
	}
}

void SettingScene::More(Ref*, TouchEventType type)
{
	switch (type)
	{
	case TouchEventType::TOUCH_EVENT_ENDED:
		//Director::getInstance()->replaceScene(MoreScene::createScene());
		break;
	}
}

void SettingScene::BanVolume(Ref*, TouchEventType type)
{
	switch (type)
	{
	case TouchEventType::TOUCH_EVENT_ENDED:
		if(m_isPlaying)
		{
			m_sprite->setVisible(true);
			CocosDenshion::SimpleAudioEngine::getInstance()->pauseBackgroundMusic();
			m_isPlaying = false;
			UserDefault::getInstance()->setBoolForKey("PlayingStateKey", m_isPlaying);
		}
		else
		{
			m_sprite->setVisible(false);
			CocosDenshion::SimpleAudioEngine::sharedEngine()->resumeBackgroundMusic();
			CocosDenshion::SimpleAudioEngine::sharedEngine()->setBackgroundMusicVolume(0.0f);
			m_isPlaying = true;
			UserDefault::getInstance()->setBoolForKey("PlayingStateKey", m_isPlaying);
		}
		break;
	}
}