#ifndef _MonsterManager_H_
#define _MonsterManager_H_

#include "Monster.h"
#include "cocos2d.h"
USING_NS_CC;

#define MAX_MONSTER_NUM 3

class MonsterManager : public Node
{
public:
	CREATE_FUNC(MonsterManager);
	virtual bool init();
	virtual void update(float dt);
public:
	void bindPlayer(Player* player);
private:
	void createMonster();
private:
	Vector<Monster*> m_monsterArr;
	Player* m_player;
};

#endif 
