#include "MainScene.h"
#include "LogoutScene.h"
#include "SettingScene.h"
#include "SelectGameScene.h"
#include "RankingScene.h"

Scene* MainScene::createScene()
{
	auto scene = Scene::create();
	auto layer = MainScene::create();
	scene->addChild(layer);
	return scene;
}

bool MainScene::init()
{
	if (!Layer::init())
	{
		return false;
	}

	
	loadSprite();
	loadUI();

	return true;
}

void MainScene::loadUI()
{
	auto UI = GUIReader::getInstance()->widgetFromJsonFile("MainScene_1.ExportJson");
	UI->setPosition(Point(0, 0));
	this->addChild(UI, 1);

	Button* btn_1 = (Button*)Helper::seekWidgetByName(UI, "animal");
	Button* btn_2 = (Button*)Helper::seekWidgetByName(UI, "player");
	Button* btn_3 = (Button*)Helper::seekWidgetByName(UI, "pet");
	Button* btn_4 = (Button*)Helper::seekWidgetByName(UI, "setting");
	Button* btn_5 = (Button*)Helper::seekWidgetByName(UI, "message");
	Button* btn_6 = (Button*)Helper::seekWidgetByName(UI, "friend");
	Button* btn_7 = (Button*)Helper::seekWidgetByName(UI, "logout");
	Button* btn_8 = (Button*)Helper::seekWidgetByName(UI, "adventure");
	Button* btn_9 = (Button*)Helper::seekWidgetByName(UI, "classicalModel");
	Button* btn_10 = (Button*)Helper::seekWidgetByName(UI, "shop");
	
	btn_1->addTouchEventListener(this, toucheventselector(MainScene::Wait));
	btn_2->addTouchEventListener(this, toucheventselector(MainScene::Wait));
	btn_3->addTouchEventListener(this, toucheventselector(MainScene::Wait));
	btn_4->addTouchEventListener(this, toucheventselector(MainScene::Set));
	btn_5->addTouchEventListener(this, toucheventselector(MainScene::Rank));
	btn_6->addTouchEventListener(this, toucheventselector(MainScene::Wait));
	btn_7->addTouchEventListener(this, toucheventselector(MainScene::Logout));
	btn_8->addTouchEventListener(this, toucheventselector(MainScene::Wait));
	btn_9->addTouchEventListener(this, toucheventselector(MainScene::Select));
	btn_10->addTouchEventListener(this, toucheventselector(MainScene::Wait));
}

void MainScene::loadSprite()
{
	Size size = Director::getInstance()->getVisibleSize();

	m_sprite = Sprite::create("wait.png");
	m_sprite->setPosition(size.width / 2, size.height / 2);
	m_sprite->setVisible(false);
	this->addChild(m_sprite, 3);

	m_player = Sprite::create("jinqiang3.png");
	m_player->setPosition(Point(260, 310));
	m_player->setScale(0.7f);
	this->addChild(m_player, 2);
}

void MainScene::Logout(Ref*, TouchEventType type)
{
	switch (type)
	{
	case TouchEventType::TOUCH_EVENT_ENDED:
		Director::getInstance()->replaceScene(LogoutScene::createScene());
		break;
	}
}

void MainScene::Wait(Ref*, TouchEventType type)
{
	switch (type)
	{
	case TouchEventType::TOUCH_EVENT_BEGAN:
		m_sprite->setVisible(true);
		break;
	case TouchEventType::TOUCH_EVENT_ENDED:

		CallFunc* callFunc = CallFunc::create([&]()
		{
			m_sprite->setVisible(false);
		});

		m_sprite->runAction(callFunc);
		break;
	}
}

void MainScene::Set(Ref*, TouchEventType type)
{
	switch (type)
	{
	case TouchEventType::TOUCH_EVENT_ENDED:
		Director::getInstance()->pushScene(SettingScene::createScene());
		break;
	}
}

void MainScene::Select(Ref*, TouchEventType type)
{
	switch (type)
	{
	case TouchEventType::TOUCH_EVENT_ENDED:
		Director::getInstance()->replaceScene(SelectGameScene::createScene());
		break;
	}
}

void MainScene::Rank(Ref*, TouchEventType type)
{
	switch (type)
	{
	case TouchEventType::TOUCH_EVENT_ENDED:
		Director::getInstance()->replaceScene(RankingScene::createScene());
		break;
	}
}