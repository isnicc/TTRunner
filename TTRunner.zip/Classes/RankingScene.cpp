#include "RankingScene.h"
#include "MainScene.h"

Scene* RankingScene::createScene()
{
	auto scene = Scene::create();
	auto layer = RankingScene::create();
	scene->addChild(layer);
	return scene;
}

bool RankingScene::init()
{
	if (!Layer::init())
	{
		return false;
	}

	Size size = Director::getInstance()->getVisibleSize();
	auto sprite = Sprite::create("background.png");
	sprite->setPosition(Point(size.width / 2, size.height / 2));
	this->addChild(sprite, 0);

	this->loadUI();
	this->readData();
	this->show();

	return true;
}

void RankingScene::loadUI()
{
	auto UI = GUIReader::getInstance()->widgetFromJsonFile("RankIngSceneUI.ExportJson");
	UI->setPosition(Point(0, 0));
	this->addChild(UI, 1);

	auto btn = (Button*)Helper::seekWidgetByName(UI, "returnBtn");
	m_NO1Lab = (Text*)Helper::seekWidgetByName(UI, "NO1Lab");
	m_NO2Lab = (Text*)Helper::seekWidgetByName(UI, "NO2Lab");
	m_NO3Lab = (Text*)Helper::seekWidgetByName(UI, "NO3Lab");

	btn->addTouchEventListener(this, toucheventselector(RankingScene::Return));
}

void RankingScene::Return(Ref*, TouchEventType type)
{
	switch (type)
	{
	case TouchEventType::TOUCH_EVENT_ENDED:
		Director::getInstance()->replaceScene(MainScene::createScene());
		break;
	}
}

void RankingScene::show()
{
	m_NO1Lab->setText(Value(m_NO1).asString());
	m_NO2Lab->setText(Value(m_NO2).asString());
	m_NO3Lab->setText(Value(m_NO3).asString());
}

void RankingScene::readData()
{
	Json::Reader reader;
	Json::Value root;

	std::string data = FileUtils::getInstance()->getStringFromFile("GameData.json");

	if (reader.parse(data, root, false) == true)
	{
		m_NO1 = root["NO1Score"].asInt();
		m_NO2 = root["NO2Score"].asInt();
		m_NO3 = root["NO3Score"].asInt();
	}
}