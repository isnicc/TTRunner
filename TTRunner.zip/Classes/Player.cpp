#include "Player.h"
#include "FlowWord.h"
#include "SimpleAudioEngine.h"

Player* Player::create(const char* fileName)
{
	Player * sprite = new Player();  

	if (sprite&& sprite->initWithFile(fileName))  

	{  
		sprite->autorelease(); 
		return sprite;  
	}  

	CC_SAFE_DELETE(sprite);  
	return nullptr;
}

void Player::setData()
{
	m_jumping = false;
	m_jumpingTwice = false;
	m_slipping = false;
	m_isHitting = false;
	m_iHP = 200;
	m_xSpeed = 4;
	m_countNumber = 0;
	m_score = 0;
	m_distanceScore = 0;
	m_bonus = 0;
	m_distance = 0;
	m_hpPercent = 100.0f;

	m_isCounting = false;
	m_victory = false;
}

void Player::update(float dt)
{
	Point pos = this->getPosition();  //���ϸ�����������
	pos.x += m_xSpeed;
	this->setTagPosition(pos.x, pos.y);

	m_countNumber += 50;
	m_distanceScore = m_countNumber / 40;
	m_distance = m_distanceScore / 25;
	m_hpPercent = m_iHP / 200.0f * 100;
	m_score = m_distanceScore + m_bonus;

	if (m_isCounting == false)
	{
		return;
	}
	m_fTime += dt;

	if(m_fTime >= m_fCBTime)
	{
		m_func();
		m_isCounting = false;
	}
}

float Player::getHpPercent()
{
	return m_hpPercent;
}

int Player::getHp()
{
	return m_iHP;
}

int Player::getScore()
{
	return m_score;
}

int Player::getDistance()
{
	return m_distance;
}

void Player::safeTime(float fCBtime, std::function<void()>func)
{
	m_fCBTime = fCBtime;
	m_func = func;
	m_fTime = 0;
	m_isCounting = true;
}

void Player::setSlippingState(bool x)
{
	m_slipping = x;
}

bool Player::getHittingState()
{
	return m_isHitting;
}

//Ϊʲô��Ծ֮��Y�����仯������
void Player::jump()           //һ����Ծ��ֹͣ���ܣ���Ծ���������±���
{
	//һ����
	if(!m_jumping)
	{
		m_jumping = true;

		this->stopAllActions();

		this->stopAllActions();

		Point pos = this->getPosition();
		pos.x += 15;

		JumpTo* jumpTo = JumpTo::create(1.0f, Point(pos.x, 222), 200, 1);

		auto callFunc = CallFunc::create([&]()
								{
									m_jumping = false;//��Ծ������ʼ����
									this->runAction(this->run());
									CocosDenshion::SimpleAudioEngine::getInstance()
										->playEffect("r_landing.wav");
								});

		Action* action = Sequence::create(jumpTo, callFunc, NULL);

		this->runAction(this->jumpAction());
		CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("r_jump.wav");
		this->runAction(action);
	}
	//������
	else if(m_jumping && !m_jumpingTwice)
	{
		m_jumpingTwice = true;

		this->stopAllActions();
		
		Point pos = this->getPosition();
		pos.x += 15;

		JumpTo* jumpTo = JumpTo::create(0.8f, Point(pos.x, 222), 150, 1);

		auto callFunc = CallFunc::create([&]()
								{
									m_jumping = false;              //��Ծ������ʼ����
									m_jumpingTwice = false;
									this->runAction(this->run());
									CocosDenshion::SimpleAudioEngine::getInstance()
										->playEffect("r_landing.wav");
								});
		Action* action = Sequence::create(jumpTo, callFunc, NULL);
		
		this->runAction(this->jumpTwiceAction());
		CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("r_second_jump_boy.wav");
		this->runAction(action);
	}
	else
	{
		return;
	}
}

bool Player::isJumping()
{
	return m_jumping;
}

void Player::hit()
{
	m_isHitting = true;
	FlowWord* flowWord = FlowWord::create();
	this->addChild(flowWord);
	flowWord->showWord("-20", this->getOffsetPosition());

	m_iHP -= 20;
	if(m_iHP <= 0)
	{
		m_iHP = 0;
	}

	auto backMove = MoveBy::create(0.1f, Point(-30, 0));
	auto forwardMove = MoveBy::create(0.1f, Point(30, 0));
	auto backRotate = RotateBy::create(0.1f, -5, 0);
	auto forwardRotate = RotateBy::create(0.1f, 5, 0);

	auto backAction = Spawn::create(backMove, backRotate, NULL);
	auto forwardAction = Spawn::create(forwardMove, forwardRotate, NULL);

	auto action = Sequence::create(backAction, forwardAction, NULL);
	this->runAction(action);
	this->safeTime(2.0f, [&](){m_isHitting = false;});
}

Action* Player::run()      //����һ���ܵ�֡����
{
	SpriteFrameCache* frameCache = SpriteFrameCache::getInstance();
	frameCache->addSpriteFramesWithFile("shuanqiang.plist", "shuanqiang.png");

	SpriteFrame* frame = NULL;
	Vector<SpriteFrame*> frameList;

	for(int i = 1; i <= 12; i++)
	{
		frame = frameCache->getSpriteFrameByName(StringUtils::format("shuanqiang%d.png", i));
		frameList.pushBack(frame);
	}

	Animation* animation = Animation::createWithSpriteFrames(frameList);
	animation->setLoops(-1);
	animation->setDelayPerUnit(0.08f);

	Animate* action = Animate::create(animation);
	return action;
}

Action* Player::jumpAction()
{
	SpriteFrameCache* frameCache = SpriteFrameCache::getInstance();
	frameCache->addSpriteFramesWithFile("jump.plist", "jump.png");

	SpriteFrame* frame = NULL;
	Vector<SpriteFrame*> frameList;

	for(int i = 1; i <= 2; i++)
	{
		frame = frameCache->getSpriteFrameByName(StringUtils::format("shuanqiang_jump%d.png", i));
		frameList.pushBack(frame);
	}

	Animation* animation = Animation::createWithSpriteFrames(frameList);
	animation->setLoops(1);
	animation->setDelayPerUnit(0.5f);

	Animate* action = Animate::create(animation);
	return action;
}

Action* Player::jumpTwiceAction()
{
	SpriteFrameCache* frameCache = SpriteFrameCache::getInstance();
	frameCache->addSpriteFramesWithFile("jumpTwice.plist", "jumpTwice.png");

	SpriteFrame* frame = NULL;
	Vector<SpriteFrame*> frameList;

	for(int i = 1; i <= 5; i++)
	{
		frame = frameCache->getSpriteFrameByName(StringUtils::format("shuanqiang_jumpTwice%d.png", i));
		frameList.pushBack(frame);
	}

	Animation* animation = Animation::createWithSpriteFrames(frameList);
	animation->setLoops(1);
	animation->setDelayPerUnit(0.1f);

	Animate* action = Animate::create(animation);
	return action;
}

Action* Player::slipAction()
{
	SpriteFrameCache* frameCache = SpriteFrameCache::getInstance();
	frameCache->addSpriteFramesWithFile("slip.plist", "slip.png");

	SpriteFrame* frame = NULL;
	Vector<SpriteFrame*> frameList;

	for(int i = 1; i <= 2; i++)
	{
		frame = frameCache->getSpriteFrameByName(StringUtils::format("shuanqiang_slip%d.png", i));
		frameList.pushBack(frame);
	}

	Animation* animation = Animation::createWithSpriteFrames(frameList);
	animation->setLoops(1);
	animation->setDelayPerUnit(0.01f);

	Animate* action = Animate::create(animation);
	return action;
}

void Player::setTiledMap(TMXTiledMap* map)
{
	this->m_map = map; 

	this->m_meta = m_map->getLayer("meta");
	this->m_meta->setVisible(false);
}

void Player::setSpeed(int x)
{
	m_xSpeed = x;
}

//�������˶�����Ļ�е�֮�󣬾��õ�ͼ���ڵĲ㿪ʼ�����˶���
//�������Ļ��Ե�ͼ�����˶�������ʼ�մ�����Ļ�����Ч��
void Player::setViewPointByPlayer()   
{
	//��õ�ͼ���ڵĲ�
	Layer* parent = (Layer*)getParent();    
	//�õ���ͼ�ж��ٿ�
	Size mapTiledNum = m_map->getMapSize();
	//��õ�ͼÿһ������С
	Size tiledSize = m_map->getTileSize();
	//����������ͼ�ĳߴ�
	Size mapSize = Size(
		mapTiledNum.width * tiledSize.width, 
		mapTiledNum.height * tiledSize.height);
	//�����Ļ��С
	Size visibleSize = Director::getInstance()->getVisibleSize();
	//�����������
	Point spritePos = this->getPosition();
	//������Ǻ�����С����Ļ���ȵ�һ�룬�������������˶���ֱ���˶�����Ļ�е�
	float x = std::max(spritePos.x, visibleSize.width / 2);
	//��ֹ���ǳ�����ͼ��Χ
	x = std::min(x, mapSize.width - visibleSize.width / 2);

	Point desPos = Point(x, spritePos.y);

	Point centerPos = Point(visibleSize.width / 2, spritePos.y);
	//���������˶��ľ���
	Point viewPos = centerPos - desPos;
	//��ʱ��parent��ָ��Ĳ��ê��λ�ڵ�ͼ���ģ�parent���õ�����ϵ����տ�ʼ����λ�õ�����Ϊԭ��
	parent->setPosition(viewPos);

}

void Player::setTagPosition(int x, int y)
{

	Size spriteSize = this->getContentSize();
	Point desPos = Point(x + spriteSize.width / 2, y);

	//����ĸ����Ǵ���������������������
	Point tiledPos_1 = tileCoordForPosition(Point(desPos.x, desPos.y));
	Point tiledPos_2 = Point(tiledPos_1.x, tiledPos_1.y - 1);
	Point tiledPos_3 = Point(tiledPos_1.x, tiledPos_1.y + 1);
	Point tiledPos_4 = Point(tiledPos_1.x - 1, tiledPos_1.y);
	Point tiledPos_5 = Point(tiledPos_1.x - 1, tiledPos_1.y - 1);
	Point tiledPos_6 = Point(tiledPos_1.x - 1, tiledPos_1.y + 1);
	Point tiledPos_7 = Point(tiledPos_1.x - 2, tiledPos_1.y);
	Point tiledPos_8 = Point(tiledPos_1.x - 2, tiledPos_1.y - 1);
	Point tiledPos_9 = Point(tiledPos_1.x - 2, tiledPos_1.y + 1);

	

	int tiledGid_1 = m_meta->getTileGIDAt(tiledPos_1);
	int tiledGid_2 = m_meta->getTileGIDAt(tiledPos_2);
	int tiledGid_3 = m_meta->getTileGIDAt(tiledPos_3);
	int tiledGid_4 = m_meta->getTileGIDAt(tiledPos_4);
	int tiledGid_5 = m_meta->getTileGIDAt(tiledPos_5);
	int tiledGid_6 = m_meta->getTileGIDAt(tiledPos_6);
	int tiledGid_7 = m_meta->getTileGIDAt(tiledPos_7);
	int tiledGid_8 = m_meta->getTileGIDAt(tiledPos_8);
	int tiledGid_9 = m_meta->getTileGIDAt(tiledPos_9);

	if(m_slipping == false)       //����û���»���Ҫ�жϾŸ�����
	{
		if(tiledGid_1 != 0)
		{
			Value properties = m_map->getPropertiesForGID(tiledGid_1);

			ValueMap propertiesMap = properties.asValueMap();

			if(propertiesMap.find("Collidable") != propertiesMap.end())
			{
				Value prop = propertiesMap.at("Collidable");

				if(prop.asString().compare("true") == 0 && m_isHitting == false)
				{
					this->hit();
				}
			}

			if (propertiesMap.find("Gold") != propertiesMap.end())
			{
				Value prop = properties.asValueMap().at("Gold");
				if(prop.asString().compare("true") == 0)
				{
					m_bonus += 50;
					TMXLayer* gold = m_map->getLayer("gold");
					gold->removeTileAt(tiledPos_1);
					CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("addScore.wav");
				}
			}

			if (propertiesMap.find("win") != propertiesMap.end())
			{
				Value prop = properties.asValueMap().at("win");
				if(prop.asString().compare("true") == 0)
				{
					m_victory = true;
				}
			}
		}

		if(tiledGid_2 != 0)
		{
			Value properties = m_map->getPropertiesForGID(tiledGid_2);

			ValueMap propertiesMap = properties.asValueMap();

			if(propertiesMap.find("Collidable") != propertiesMap.end())
			{
				Value prop = propertiesMap.at("Collidable");

				if(prop.asString().compare("true") == 0 && m_isHitting == false)
				{
					this->hit();
				}
			}

			if (propertiesMap.find("Gold") != propertiesMap.end())
			{
				Value prop = properties.asValueMap().at("Gold");
				if(prop.asString().compare("true") == 0)
				{
					m_bonus += 50;
					TMXLayer* gold = m_map->getLayer("gold");
					gold->removeTileAt(tiledPos_2);
					CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("addScore.wav");
				}
			}

			if (propertiesMap.find("win") != propertiesMap.end())
			{
				Value prop = properties.asValueMap().at("win");
				if(prop.asString().compare("true") == 0)
				{
					m_victory = true;
				}
			}
		}

		if(tiledGid_3 != 0)
		{
			Value properties = m_map->getPropertiesForGID(tiledGid_3);

			ValueMap propertiesMap = properties.asValueMap();

			if(propertiesMap.find("Collidable") != propertiesMap.end())
			{
				Value prop = propertiesMap.at("Collidable");

				if(prop.asString().compare("true") == 0 && m_isHitting == false)
				{
					this->hit();
				}
			}

			if (propertiesMap.find("Gold") != propertiesMap.end())
			{
				Value prop = properties.asValueMap().at("Gold");
				if(prop.asString().compare("true") == 0)
				{
					m_bonus += 50;
					TMXLayer* gold = m_map->getLayer("gold");
					gold->removeTileAt(tiledPos_3);
					CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("addScore.wav");
				}
			}

			if (propertiesMap.find("win") != propertiesMap.end())
			{
				Value prop = properties.asValueMap().at("win");
				if(prop.asString().compare("true") == 0)
				{
					m_victory = true;
				}
			}
		}

		if(tiledGid_4 != 0)
		{
			Value properties = m_map->getPropertiesForGID(tiledGid_4);

			ValueMap propertiesMap = properties.asValueMap();

			if(propertiesMap.find("Collidable") != propertiesMap.end())
			{
				Value prop = propertiesMap.at("Collidable");

				if(prop.asString().compare("true") == 0 && m_isHitting == false)
				{
					this->hit();
				}
			}
			if (propertiesMap.find("Gold") != propertiesMap.end())
			{
				Value prop = properties.asValueMap().at("Gold");
				if(prop.asString().compare("true") == 0)
				{
					m_bonus += 50;
					TMXLayer* gold = m_map->getLayer("gold");
					gold->removeTileAt(tiledPos_4);
					CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("addScore.wav");
				}
			}

		}

		if(tiledGid_5 != 0)
		{
			Value properties = m_map->getPropertiesForGID(tiledGid_5);

			ValueMap propertiesMap = properties.asValueMap();

			if(propertiesMap.find("Collidable") != propertiesMap.end())
			{
				Value prop = propertiesMap.at("Collidable");

				if(prop.asString().compare("true") == 0 && m_isHitting == false)
				{
					this->hit();
				}
			}
			if (propertiesMap.find("Gold") != propertiesMap.end())
			{
				Value prop = properties.asValueMap().at("Gold");
				if(prop.asString().compare("true") == 0)
				{
					m_bonus += 50;
					TMXLayer* gold = m_map->getLayer("gold");
					gold->removeTileAt(tiledPos_5);
					CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("addScore.wav");
				}
			}

		}

		if(tiledGid_6 != 0)
		{
			Value properties = m_map->getPropertiesForGID(tiledGid_6);

			ValueMap propertiesMap = properties.asValueMap();

			if(propertiesMap.find("Collidable") != propertiesMap.end())
			{
				Value prop = propertiesMap.at("Collidable");

				if(prop.asString().compare("true") == 0 && m_isHitting == false)
				{
					this->hit();
				}
			}
			if (propertiesMap.find("Gold") != propertiesMap.end())
			{
				Value prop = properties.asValueMap().at("Gold");
				if(prop.asString().compare("true") == 0)
				{
					m_bonus += 50;
					TMXLayer* gold = m_map->getLayer("gold");
					gold->removeTileAt(tiledPos_6);
					CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("addScore.wav");
				}
			}

		}

		if(tiledGid_7 != 0)
		{
			Value properties = m_map->getPropertiesForGID(tiledGid_7);

			ValueMap propertiesMap = properties.asValueMap();

			if(propertiesMap.find("Collidable") != propertiesMap.end())
			{
				Value prop = propertiesMap.at("Collidable");

				if(prop.asString().compare("true") == 0 && m_isHitting == false)
				{
					this->hit();
				}
			}
			if (propertiesMap.find("Gold") != propertiesMap.end())
			{
				Value prop = properties.asValueMap().at("Gold");
				if(prop.asString().compare("true") == 0)
				{
					m_bonus += 50;
					TMXLayer* gold = m_map->getLayer("gold");
					gold->removeTileAt(tiledPos_7);
					CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("addScore.wav");
				}
			}

		}

		if(tiledGid_8 != 0)
		{
			Value properties = m_map->getPropertiesForGID(tiledGid_8);

			ValueMap propertiesMap = properties.asValueMap();

			if(propertiesMap.find("Collidable") != propertiesMap.end())
			{
				Value prop = propertiesMap.at("Collidable");

				if(prop.asString().compare("true") == 0 && m_isHitting == false)
				{
					this->hit();
				}
			}
			if (propertiesMap.find("Gold") != propertiesMap.end())
			{
				Value prop = properties.asValueMap().at("Gold");
				if(prop.asString().compare("true") == 0)
				{
					m_bonus += 50;
					TMXLayer* gold = m_map->getLayer("gold");
					gold->removeTileAt(tiledPos_8);
					CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("addScore.wav");
				}
			}

		}

		if(tiledGid_9 != 0)
		{
			Value properties = m_map->getPropertiesForGID(tiledGid_9);

			ValueMap propertiesMap = properties.asValueMap();

			if(propertiesMap.find("Collidable") != propertiesMap.end())
			{
				Value prop = propertiesMap.at("Collidable");

				if(prop.asString().compare("true") == 0 && m_isHitting == false)
				{
					this->hit();
				}
			}
			if (propertiesMap.find("Gold") != propertiesMap.end())
			{
				Value prop = properties.asValueMap().at("Gold");
				if(prop.asString().compare("true") == 0)
				{
					m_bonus += 50;
					TMXLayer* gold = m_map->getLayer("gold");
					gold->removeTileAt(tiledPos_9);
					CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("addScore.wav");
				}
			}

		}
	}

	if (m_slipping == true)      //�����»�����ֻ���ж���������
	{
		if(tiledGid_1 != 0)
		{
			Value properties = m_map->getPropertiesForGID(tiledGid_1);

			ValueMap propertiesMap = properties.asValueMap();

			if(propertiesMap.find("Collidable") != propertiesMap.end())
			{
				Value prop = propertiesMap.at("Collidable");

				if(prop.asString().compare("true") == 0 && m_isHitting == false)
				{
					this->hit();
				}
			}

			if (propertiesMap.find("Gold") != propertiesMap.end())
			{
				Value prop = properties.asValueMap().at("Gold");
				if(prop.asString().compare("true") == 0)
				{
					TMXLayer* gold = m_map->getLayer("gold");
					gold->removeTileAt(tiledPos_1);
					CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("addScore.wav");
				}
			}

			if (propertiesMap.find("win") != propertiesMap.end())
			{
				Value prop = properties.asValueMap().at("win");
				if(prop.asString().compare("true") == 0)
				{
					m_victory = true;
				}
			}
		}

		if(tiledGid_3 != 0)
		{
			Value properties = m_map->getPropertiesForGID(tiledGid_3);

			ValueMap propertiesMap = properties.asValueMap();

			if(propertiesMap.find("Collidable") != propertiesMap.end())
			{
				Value prop = propertiesMap.at("Collidable");

				if(prop.asString().compare("true") == 0 && m_isHitting == false)
				{
					this->hit();
				}
			}

			if (propertiesMap.find("Gold") != propertiesMap.end())
			{
				Value prop = properties.asValueMap().at("Gold");
				if(prop.asString().compare("true") == 0)
				{
					TMXLayer* gold = m_map->getLayer("gold");
					gold->removeTileAt(tiledPos_3);
					CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("addScore.wav");
				}
			}

			if (propertiesMap.find("win") != propertiesMap.end())
			{
				Value prop = properties.asValueMap().at("win");
				if(prop.asString().compare("true") == 0)
				{
					m_victory = true;
				}
			}
		}
	}


	this->setPosition(x, y);

	setViewPointByPlayer();
}

Point Player::tileCoordForPosition(Point pos)
{
	Size mapTiledNum = m_map->getMapSize();
	Size tiledSize = m_map->getTileSize();

	int x = pos.x / tiledSize.width;
	int y = (500 - pos.y) / tiledSize.height;

	if(x > 0)
	{
		x -= 1;
	}

	if(y > 0)
	{
		y -= 0;
	}
	return Point(x,y);
}

bool Player::isVictory()
{
	return m_victory;
}