#include "SelectGameScene.h"
#include "TollgateScene.h"
#include "MainScene.h"
#include "SimpleAudioEngine.h"


Scene* SelectGameScene::createScene()
{
	auto scene = Scene::create();
	auto layer = SelectGameScene::create();
	scene->addChild(layer);
	return scene;
}

bool SelectGameScene::init()
{
	if (!Layer::init())
	{
		return false;
	}


	loadSprite();
	loadUI();

	return true;
}

void SelectGameScene::loadUI()
{
	auto UI = GUIReader::getInstance()->widgetFromJsonFile("SelectGameScene_1.ExportJson");
	UI->setPosition(Point(0, 0));
	this->addChild(UI, 1);

	Button* btn_1 = (Button*)Helper::seekWidgetByName(UI, "startBtn_1");
	Button* btn_2 = (Button*)Helper::seekWidgetByName(UI, "startBtn_2");
	Button* btn_3 = (Button*)Helper::seekWidgetByName(UI, "return");
	Button* btn_4 = (Button*)Helper::seekWidgetByName(UI, "selectBtn_1");
	Button* btn_5 = (Button*)Helper::seekWidgetByName(UI, "selectBtn_2");


	btn_1->addTouchEventListener(this, toucheventselector(SelectGameScene::BeginGame_1));
	btn_2->addTouchEventListener(this, toucheventselector(SelectGameScene::BeginGame_2));
	btn_3->addTouchEventListener(this, toucheventselector(SelectGameScene::Return));
}

void SelectGameScene::loadSprite()
{
	Size size = Director::getInstance()->getVisibleSize();

	auto sprite = Sprite::create("background.png");
	sprite->setPosition(size.width / 2, size.height / 2);
	this->addChild(sprite, 0);


	m_sprite = Sprite::create("wait.png");
	m_sprite->setPosition(size.width / 2, size.height / 2);
	m_sprite->setVisible(false);
	this->addChild(m_sprite, 2);
}

void SelectGameScene::BeginGame_1(Ref*, TouchEventType type)
{
	switch (type)
	{
	case TouchEventType::TOUCH_EVENT_ENDED:
		CocosDenshion::SimpleAudioEngine::getInstance()->stopBackgroundMusic();
		Director::getInstance()->replaceScene(TollgateScene::createScene());
		break;
	}
}

void SelectGameScene::BeginGame_2(Ref*, TouchEventType type)
{
	switch (type)
	{
	case TouchEventType::TOUCH_EVENT_BEGAN:
		m_sprite->setVisible(true);
		break;
	case TouchEventType::TOUCH_EVENT_ENDED:

		CallFunc* callFunc = CallFunc::create([&]()
		{
			m_sprite->setVisible(false);
		});

		m_sprite->runAction(callFunc);
		break;
	}
}

void SelectGameScene::Return(Ref*, TouchEventType type)
{
	switch (type)
	{
	case TouchEventType::TOUCH_EVENT_ENDED:
		Director::getInstance()->replaceScene(MainScene::createScene());
		break;
	}
}