#ifndef _GameEndScene_H_
#define _GameEndScene_H_

#include "cocos2d.h"
#include "editor-support/cocostudio/CCSGUIReader.h"
#include "ui/CocosGUI.h"

USING_NS_CC;
using namespace cocostudio;
using namespace ui;

class GameEndScene : public Layer
{
public:
	static Scene* createScene(RenderTexture* renderTexture);
	virtual bool init();
	CREATE_FUNC(GameEndScene);
	virtual void update(float dt);
public:
	void loadUI();
	void loadSprite();
	void startAgain(Ref*, TouchEventType type);
	void returnToMainScene(Ref*, TouchEventType type);
	void CountDown(float time, std::function<void()>func);
private:
	Text* m_scoreLab;
	Text* m_distanceLab;
	int m_socre;
	int m_distance;
	bool m_win;
	int m_count;      //���������������ʱ�Ķ���
private:
	void readData();
private:
	float m_countTime;
	float m_time;
	bool m_isCounting;
	std::function<void()> m_func;
private:
	Sprite* m_sprite;
	std::string m_spriteName;
};

#endif
