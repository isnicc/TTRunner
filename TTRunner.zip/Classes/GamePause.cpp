#include "GamePause.h"
#include "TollgateScene.h"
#include "RankingScene.h"
#include "SimpleAudioEngine.h"

Scene* GamePause::createScene(RenderTexture* renderTexture)
{
	auto scene = Scene::create();
	auto layer = GamePause::create();
	scene->addChild(layer, 1);

	Size visibleSize = Director::getInstance()->getVisibleSize();

	//�������д������û�õ�������Ҳ���ǽ�ͼ������һ�����飬����������Ϊ����
	Sprite* background = Sprite::createWithTexture(renderTexture->getSprite()->getTexture());
	background->setPosition(Point(visibleSize.width / 2, visibleSize.height / 2));
	background->setFlippedY(true);   //������Ҫ��ֱ��ת����Ϊ����OpenGL����
	background->setColor(ccc3(128,128,128));   //����ͼƬΪ��ɫ
	scene->addChild(background, 0);

	return scene;
}

bool GamePause::init()
{
	if (!Layer::init())
	{
		return false;
	}

	loadUI();

	return true;
}

void GamePause::loadUI()
{
	auto UI = GUIReader::getInstance()->widgetFromJsonFile("TTRun_pause_1.ExportJson");
	UI->setPosition(Point(0, 0));
	this->addChild(UI);   //�����ǰ�UI���ӵ�createScene��layer������

	Button* continueBtn = (Button*)Helper::seekWidgetByName(UI, "continueBtn");
	Button* restartBtn = (Button*)Helper::seekWidgetByName(UI, "restartBtn");
	Button* rankBtn = (Button*)Helper::seekWidgetByName(UI, "rankBtn");

	continueBtn->addTouchEventListener(this, toucheventselector(GamePause::backToGame));
	restartBtn->addTouchEventListener(this, toucheventselector(GamePause::restartGame));
	rankBtn->addTouchEventListener(this, toucheventselector(GamePause::backToRankingScene));
}

void GamePause::backToGame(Ref*, TouchEventType type)
{
	switch (type)
	{
	case TouchEventType::TOUCH_EVENT_ENDED:
		CocosDenshion::SimpleAudioEngine::getInstance()->resumeBackgroundMusic();
		Director::getInstance()->popScene();
		break;
	}
}

void GamePause::restartGame(Ref*, TouchEventType type)
{
	switch (type)
	{
	case TouchEventType::TOUCH_EVENT_ENDED:
		Director::getInstance()->replaceScene(TollgateScene::createScene());
		break;
	}
}

void GamePause::backToRankingScene(Ref*, TouchEventType type)  // ���а�
{
	switch (type)
	{
	case TouchEventType::TOUCH_EVENT_ENDED:
		CocosDenshion::SimpleAudioEngine::getInstance()->playBackgroundMusic("TTRunBgm.mp3",true);
		Director::getInstance()->replaceScene(RankingScene::createScene());
		break;
	}
}