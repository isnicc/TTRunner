#include "GameEndScene.h"
#include "TollgateScene.h"
#include "MainScene.h"
#include "SimpleAudioEngine.h"

#include "json\writer.h"
#include "json\reader.h"
#include "json\value.h"

Scene* GameEndScene::createScene(RenderTexture* renderTexture)
{

	auto scene = Scene::create();
	auto layer = GameEndScene::create();
	scene->addChild(layer, 1);

	Size visibleSize = Director::getInstance()->getVisibleSize();
	auto sprite = Sprite::createWithTexture(renderTexture->getSprite()->getTexture());
	sprite->setPosition(Point(visibleSize.width / 2, visibleSize.height / 2));
	sprite->setFlippedY(true);
	scene->addChild(sprite, 0);

	return scene;
}

bool GameEndScene::init()
{
	if (!Layer::init())
	{
		return false;
	}

	m_count = 0;
	
	this->readData();
	auto func = [&]()
	{

		//this->readData();
		this->loadUI();
		this->loadSprite();

		auto listener = EventListenerTouchOneByOne::create();
		listener->onTouchBegan = [](Touch* touch, Event* event){return true;};

		listener->onTouchEnded = [&](Touch* touch, Event* event)      //�����õ���thisָ������ݳ�Ա����Ҫʹ�����ò���ģʽ
		{
			this->unscheduleUpdate();
			m_scoreLab->setText(Value(m_socre).asString());
		};

		Director::getInstance()->
			getEventDispatcher()->addEventListenerWithSceneGraphPriority(listener, this);
	};

	if (m_win == false)
	{
		CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("gameOver.wav");
	}
	else
	{
		CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("victory.wav");
	}
	this->CountDown(4.0f, func);

	this->scheduleUpdate();

	return true;
}

void GameEndScene::update(float dt)
{
	if (m_isCounting == true)
	{
		m_countTime += dt;
		if (m_countTime < m_time)
		{
			return;
		}
		else
		{
			m_isCounting = false;
			m_func();
			return;
		}
	}

	if (m_count <= m_socre)
	{
		CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("addScore.wav");
		m_count += 1;
		m_scoreLab->setText(Value(m_count).asString());
	}
}

void GameEndScene::readData()
{
	Json::Value root;
	Json::Reader reader;

	std::string data = FileUtils::getInstance()->getStringFromFile("GameData.json");

	if(reader.parse(data, root, false) == true)
	{
		m_socre = root["ScoreKey"].asInt() + root["HpKey"].asInt() * 1000;
		m_distance = root["DistanceKey"].asInt();
		m_spriteName = root["SpriteName"].asString();
		if (root["HpKey"].asInt() == 0)
		{
			m_win = false;
		}
		else
		{
			m_win = true;
		}
	}
}

void GameEndScene::loadUI()
{
	auto UI = GUIReader::getInstance()->widgetFromJsonFile("GameEndUI_1.ExportJson");
	UI->setPosition(Point(0, 0));
	this->addChild(UI, 0);

	Button* btn_1 = (Button*)Helper::seekWidgetByName(UI, "fanhuiBtn");
	Button* btn_2 = (Button*)Helper::seekWidgetByName(UI, "zailaiBtn");
	m_scoreLab = (Text*)Helper::seekWidgetByName(UI, "scoreLab");
	m_distanceLab = (Text*)Helper::seekWidgetByName(UI, "distanceLab");

	btn_1->addTouchEventListener(this, toucheventselector(GameEndScene::returnToMainScene));
	btn_2->addTouchEventListener(this, toucheventselector(GameEndScene::startAgain));
	m_distanceLab->setText(Value(m_distance).asString());

}

void GameEndScene::loadSprite()
{
	m_sprite = Sprite::create(m_spriteName);
	m_sprite->setPosition(Point(200, 380));
	this->addChild(m_sprite, 1);


	auto sprite = Sprite::create("jinqiang3.png");
	sprite->setPosition(Point(590, 300));
	sprite->setScale(0.7f);
	this->addChild(sprite, 1);

	auto listener = EventListenerTouchOneByOne::create();
	listener->onTouchBegan = [](Touch* touch, Event* event){return true;};

	listener->onTouchEnded = [&](Touch* touch, Event* event)      //�����õ���thisָ������ݳ�Ա����Ҫʹ�����ò���ģʽ
	{
		this->unscheduleUpdate();
		m_scoreLab->setText(Value(m_socre).asString());
	};

	Director::getInstance()->
		getEventDispatcher()->addEventListenerWithSceneGraphPriority(listener, sprite);
}

void GameEndScene::startAgain(Ref*, TouchEventType type)
{
	switch (type)
	{
	case TouchEventType::TOUCH_EVENT_ENDED:
		Director::getInstance()->replaceScene(TollgateScene::createScene());
		break;
	}
}

void GameEndScene::returnToMainScene(Ref*, TouchEventType type)
{
	switch(type)
	{
	case TouchEventType::TOUCH_EVENT_ENDED:
		CocosDenshion::SimpleAudioEngine::getInstance()->playBackgroundMusic("TTRunBgm.mp3",true);
		Director::getInstance()->replaceScene(MainScene::createScene());
		break;
	}
}

void GameEndScene::CountDown(float time, std::function<void()>func)
{
	m_isCounting = true;
	m_countTime = 0;
	m_time = time;
	m_func = func;
}