#ifndef _SureAgain_H_
#define _SureAgain_H_

#include "cocos2d.h"
#include "editor-support/cocostudio/CCSGUIReader.h"
#include "ui/CocosGUI.h"
USING_NS_CC;
using namespace cocostudio;
using namespace ui;

class SureAgain : public Layer
{
public:
	static Scene* createScene(RenderTexture* renderTexture);
	virtual bool init();
	CREATE_FUNC(SureAgain);
public:
	void loadUI();
public:
	void Return(Ref*, TouchEventType type);
	void Logout(Ref*, TouchEventType type);
};

#endif